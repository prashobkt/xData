import { Component, OnInit } from '@angular/core';
import { VisitorService } from '../../services/visitor.service';

@Component({
  selector: 'app-visitor-form',
  templateUrl: './visitor-form.component.html',
  styleUrls: ['./visitor-form.component.css']
})
export class VisitorFormComponent implements OnInit {

  constructor(private visitor: VisitorService) { }

  multiVisit: boolean = false;

  ngOnInit() {
  }

  saveVisit(form: any) {
    this.visitor.addAppointment(JSON.stringify(form)).subscribe(data => console.log(data));
  }

  // demo(){
  //   this.visitor.getUsers().subscribe((data) => {console.log(data);});
  // }

}
