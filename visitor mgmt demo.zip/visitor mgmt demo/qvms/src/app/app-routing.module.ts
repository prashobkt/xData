import { NgModule } from '@angular/core';
import { RouterModule, PreloadAllModules, Router } from '@angular/router';
import { VisitorFormComponent } from './components/visitor-form/visitor-form.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { VisitorDetailComponent } from './components/visitor-detail/visitor-detail.component';

@NgModule({
    imports: [
        RouterModule.forRoot([
            { path: 'visitorinfo', component: VisitorDetailComponent },
            { path: 'dashboard', component: DashboardComponent },
            { path: 'visitorappointment', component: VisitorFormComponent },
            { path: '', redirectTo: 'visitorappointment', pathMatch: 'full'},
            { path: '**', redirectTo: '', pathMatch: 'full' }
        ])
    ],
    exports: [ RouterModule ]
})
export class AppRoutingModule {

   
 }